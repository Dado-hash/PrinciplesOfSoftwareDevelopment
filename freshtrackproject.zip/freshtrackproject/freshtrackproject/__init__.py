#from .tasks import setup_periodic_tasks

# Esegui la configurazione delle attività periodiche di Celery quando il progetto Django viene avviato
# setup_periodic_tasks()