from django.contrib import admin
from .models import Product, ShoppingList

admin.site.register(Product)
admin.site.register(ShoppingList)
